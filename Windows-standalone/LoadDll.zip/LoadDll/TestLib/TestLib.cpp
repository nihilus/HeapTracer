// TestLib.cpp : Defines the entry point for the DLL application.
//

// Exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include "TestLib.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	hModule;
	lpReserved;

    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

ULONG TestFunction()
{
	TCHAR lpMsg[512];

	_stprintf( lpMsg, _T("TestLib.dll:TestFunction() called from process #%d"), GetCurrentProcessId() );
	
	::MessageBox( 0, lpMsg, _T("TestLib"), MB_OK );

	return 1;
}